#!/bin/bash
echo "[Supply Inventory]"
cat data/supplies.txt
read -p $'\nPress enter to return to menu...'