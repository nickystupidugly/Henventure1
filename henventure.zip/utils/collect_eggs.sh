#!/bin/bash
echo "You collected 5 eggs today!"
echo "+5 eggs collected." >> data/log.txt
read -p $'\nEggs secured! Press enter to return to menu...'