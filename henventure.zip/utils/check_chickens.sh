#!/bin/bash
echo "[Chicken Coop Report]"
cat data/chickens.txt
read -p $'\nPress enter to return to menu...'