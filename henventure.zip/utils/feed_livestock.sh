#!/bin/bash
echo "Feeding the livestock..."
echo "-1 feed bag used." >> data/log.txt
read -p $'\nAnimals are fed! Press enter to return to menu...'