# Henventure
A Stardew-Valley-style text adventure homestead game written in Bash.